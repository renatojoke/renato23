<?php
$str = "abc";
$intenger = 34;
$bool = false;

echo $bool;


if (false){
  echo"true";
}
else {
  echo"False";
}

$num1 = 5;
if($num1 = "5");
{
  echo"true";

}
else {
  echo"False";
}


$num2 = 5;
if($num2 <= "5"&& $num2 >5);
{
  echo"true";

}
else {
  echo"False";
}
?>